import { FormEvent, useState } from "react";

type Screen = "login" | "onboarding" | "dashboard" | "learn";
type Language = "Python" | "JavaScript" | "Java" | "C++";

const languages: { name: Language; mark: string; color: string; desc: string }[] = [
  { name: "Python", mark: "Py", color: "bg-[#8CC8AC]", desc: "Automation, data & AI" },
  { name: "JavaScript", mark: "JS", color: "bg-[#F4C84B]", desc: "Websites & apps" },
  { name: "Java", mark: "Jv", color: "bg-[#F19B78]", desc: "Apps & backend systems" },
  { name: "C++", mark: "C+", color: "bg-[#9CAFEF]", desc: "Games & performance" },
];

function Logo({ light = false }: { light?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className={`logo-mark ${light ? "bg-[#F4C84B] text-[#1F251F]" : "bg-[#1F251F] text-[#F4C84B]"}`}>
        <span>&lt;</span><i /><span>/&gt;</span>
      </div>
      <span className={`text-2xl font-bold tracking-[-0.06em] ${light ? "text-white" : ""}`}>CodeXP</span>
    </div>
  );
}

function Login({ onLogin }: { onLogin: () => void }) {
  const submit = (event: FormEvent) => {
    event.preventDefault();
    onLogin();
  };

  return (
    <main className="min-h-screen bg-[#F7F5EF] lg:grid lg:grid-cols-[38.2fr_61.8fr]">
      <section className="relative hidden min-h-screen overflow-hidden bg-[#20261F] p-12 text-white lg:flex lg:flex-col xl:p-16">
        <Logo light />
        <div className="relative z-10 my-auto max-w-md">
          <p className="eyebrow text-[#F4C84B]">Learn by doing</p>
          <h1 className="mt-5 text-5xl font-semibold leading-[1.02] tracking-[-0.055em] xl:text-6xl">Your ideas deserve to be built.</h1>
          <p className="mt-6 max-w-sm text-lg leading-relaxed text-[#B9C0B6]">Master a new language through short lessons, real code, and instant feedback.</p>
        </div>
        <div className="relative z-10 flex items-center gap-4 text-sm text-[#B9C0B6]">
          <div className="flex -space-x-2">
            {["AM", "SK", "JD"].map((user, index) => <span key={user} className={`avatar ${["bg-[#8CC8AC]", "bg-[#9CAFEF]", "bg-[#F19B78]"][index]}`}>{user}</span>)}
          </div>
          <span>Join 12,000+ curious builders</span>
        </div>
        <div className="code-orbit"><span>function grow() {"{"}</span><span>confidence++;</span><span>{"}"}</span></div>
      </section>

      <section className="flex min-h-screen items-center justify-center px-6 py-12 sm:px-12">
        <div className="w-full max-w-[480px]">
          <div className="mb-16 lg:hidden"><Logo /></div>
          <p className="eyebrow text-[#71766E]">Welcome to CodeXP</p>
          <h2 className="mt-3 text-4xl font-semibold tracking-[-0.05em] sm:text-5xl">Start your next chapter.</h2>
          <p className="mt-4 text-[#70746D]">Sign in to continue your learning journey.</p>
          <form className="mt-10 space-y-5" onSubmit={submit}>
            <label className="block">
              <span className="field-label">Email address</span>
              <input required type="email" placeholder="you@example.com" className="field" />
            </label>
            <label className="block">
              <div className="mb-2 flex justify-between">
                <span className="field-label !mb-0">Password</span>
                <button type="button" className="text-sm font-semibold text-[#4E745F]">Forgot password?</button>
              </div>
              <input required type="password" placeholder="At least 8 characters" className="field" />
            </label>
            <button className="primary-button w-full" type="submit">Continue to CodeXP <span>→</span></button>
          </form>
          <div className="my-8 flex items-center gap-4 text-xs uppercase tracking-[0.14em] text-[#999B95]"><span className="h-px flex-1 bg-[#DDDDD6]" />or<span className="h-px flex-1 bg-[#DDDDD6]" /></div>
          <button onClick={onLogin} className="secondary-button w-full">G&nbsp;&nbsp; Continue with Google</button>
          <p className="mt-8 text-center text-sm text-[#777A73]">New here? <button onClick={onLogin} className="font-bold text-[#20261F]">Create an account</button></p>
        </div>
      </section>
    </main>
  );
}

function Onboarding({ onChoose }: { onChoose: (languages: Language[]) => void }) {
  const [level, setLevel] = useState("beginner");
  const [mode, setMode] = useState<"choose" | "recommend">("choose");
  const [selected, setSelected] = useState<Language[]>(["Python"]);
  const toggleLanguage = (language: Language) => {
    setSelected((current) =>
      current.includes(language)
        ? current.length > 1 ? current.filter((item) => item !== language) : current
        : [...current, language],
    );
  };

  return (
    <main className="min-h-screen bg-[#F7F5EF]">
      <header className="flex items-center justify-between border-b border-[#E1E0D9] px-[6vw] py-6"><Logo /><span className="hidden text-sm text-[#747870] sm:block">Step 1 of 1 · Personalize your path</span></header>
      <div className="mx-auto grid max-w-[1360px] gap-12 px-[6vw] py-12 lg:grid-cols-[38.2fr_61.8fr] lg:py-20">
        <section>
          <p className="eyebrow text-[#657067]">Your starting point</p>
          <h1 className="mt-4 text-4xl font-semibold leading-tight tracking-[-0.05em] sm:text-5xl">Let’s build a path that fits you.</h1>
          <p className="mt-5 max-w-md leading-relaxed text-[#6F746C]">No pressure and no wrong answers. We’ll adapt lessons to your experience and goals.</p>
          <div className="mt-10 rounded-[28px] bg-[#E5ECF9] p-6">
            <div className="mb-3 text-3xl">“</div>
            <p className="font-medium leading-relaxed">The best language to learn is the one that helps you make something you care about.</p>
          </div>
        </section>
        <section>
          <div className="mb-10">
            <p className="question-number">01</p>
            <h2 className="question-title">How much coding have you done?</h2>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {[["beginner", "Just starting", "I’m completely new"], ["some", "A little", "I know the basics"], ["experienced", "Quite a bit", "I’ve built projects"]].map(([id, title, desc]) => (
                <button key={id} onClick={() => setLevel(id)} className={`choice-card ${level === id ? "choice-active" : ""}`}>
                  <span className="font-bold">{title}</span><span className="mt-1 text-xs text-[#777A73]">{desc}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="mb-10 border-t border-[#DDDDD6] pt-9">
            <p className="question-number">02</p>
            <h2 className="question-title">How do you want to continue?</h2>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <button onClick={() => setMode("choose")} className={`choice-card ${mode === "choose" ? "choice-active" : ""}`}><span className="font-bold">I have a language in mind</span><span className="mt-1 text-xs text-[#777A73]">Choose your own direction</span></button>
              <button onClick={() => setMode("recommend")} className={`choice-card ${mode === "recommend" ? "choice-active" : ""}`}><span className="font-bold">Recommend one for me</span><span className="mt-1 text-xs text-[#777A73]">Based on your goals</span></button>
            </div>
          </div>
          <div className="border-t border-[#DDDDD6] pt-9">
            <div className="flex items-end justify-between"><div><p className="question-number">03</p><h2 className="question-title">{mode === "recommend" ? "Our best match for you" : "What do you want to learn?"}</h2></div>{mode === "recommend" && <span className="rounded-full bg-[#DDEDE3] px-3 py-1 text-xs font-bold text-[#356146]">Recommended</span>}</div>
            <div className="mt-5 grid grid-cols-2 gap-3">
              {languages.map((language, index) => (
                <button key={language.name} onClick={() => mode === "choose" && toggleLanguage(language.name)} className={`language-card ${selected.includes(language.name) || (mode === "recommend" && index < 2) ? "choice-active" : ""}`}>
                  <span className={`grid h-10 w-10 place-items-center rounded-xl text-sm font-bold ${language.color}`}>{language.mark}</span>
                  <span className="flex-1"><b>{language.name}</b><small>{language.desc}</small></span>
                  {(selected.includes(language.name) || (mode === "recommend" && index < 2)) && <b className="text-[#3D7A55]">✓</b>}
                </button>
              ))}
            </div>
            <p className="mt-4 text-xs text-[#747870]">{mode === "choose" ? `${selected.length} language${selected.length > 1 ? "s" : ""} selected · choose as many as you like` : "Python and JavaScript are recommended for a versatile start"}</p>
            <button onClick={() => onChoose(mode === "recommend" ? ["Python", "JavaScript"] : selected)} className="primary-button mt-6 w-full sm:w-auto">Build my learning paths <span>→</span></button>
          </div>
        </section>
      </div>
    </main>
  );
}

const lessonCopy: Record<Language, { title: string; intro: string; code: string; hint: string }> = {
  Python: { title: "Meet the print() function", intro: "The print() function displays information on the screen. Text values go inside quotation marks.", code: 'print("Hello, CodeXP!")', hint: 'Try changing the message inside the quotes.' },
  JavaScript: { title: "Meet console.log()", intro: "console.log() sends a message to the console. It is one of the fastest ways to inspect your program.", code: 'console.log("Hello, CodeXP!");', hint: 'Try changing the message inside the quotes.' },
  Java: { title: "Your first output", intro: "System.out.println() prints a line of text. Java statements end with a semicolon.", code: 'System.out.println("Hello, CodeXP!");', hint: 'Keep the semicolon and change the message.' },
  "C++": { title: "Output with cout", intro: "std::cout sends text to your terminal. The << operator passes your message to the output stream.", code: 'std::cout << "Hello, CodeXP!";', hint: 'Change only the text between the quotes.' },
};

function Dashboard({ selectedLanguages, language, onLanguageChange, onStart, onBack }: { selectedLanguages: Language[]; language: Language; onLanguageChange: (language: Language) => void; onStart: () => void; onBack: () => void }) {
  const tracks = [
    { level: "LEVEL 1", title: "Beginner — Foundations", count: "0 / 6 complete", accent: "text-[#3D7A55]", copy: `Core ${language} syntax, variables, data types, input, output, and your first working programs.`, action: "Start level 1" },
    { level: "LEVEL 2", title: "Intermediate — Build with confidence", count: "0 / 5 complete", accent: "text-[#4F68A5]", copy: "Functions, collections, reusable logic, error handling, and practical mini-projects.", action: "Explore track" },
    { level: "LEVEL 3", title: "Advanced — Real-world projects", count: "0 / 3 complete", accent: "text-[#8B579A]", copy: "Architecture, performance, professional patterns, and a complete portfolio project.", action: "Explore track" },
  ];

  return (
    <main className="min-h-screen bg-[#F5F6F3]">
      <header className="sticky top-0 z-20 border-b border-[#DEDFD9] bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1480px] items-center justify-between px-5 py-4 sm:px-8">
          <Logo />
          <nav className="hidden items-center gap-8 text-sm font-semibold md:flex" aria-label="Dashboard navigation">
            <button className="text-[#3D7A55]">Dashboard</button>
            <button>Learning tracks</button>
            <button>Code library</button>
            <button onClick={onStart}>Playground</button>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={onStart} className="hidden rounded-xl bg-[#20251F] px-5 py-2.5 text-sm font-bold text-white sm:block">Practice</button>
            <button onClick={onBack} className="secondary-button !px-4 !py-2.5 text-sm">Change path</button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[1480px] px-5 py-7 sm:px-8 sm:py-10">
        <section className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <p className="eyebrow text-[#6A7068]">Active learning paths</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {selectedLanguages.map((item) => {
                const details = languages.find((entry) => entry.name === item)!;
                return (
                  <button key={item} onClick={() => onLanguageChange(item)} className={`flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-bold transition ${language === item ? "border-[#20251F] bg-[#20251F] text-white" : "border-[#D9DCD5] bg-white"}`}>
                    <span className={`grid h-6 w-6 place-items-center rounded-full text-[10px] text-[#20251F] ${details.color}`}>{details.mark}</span>{item}
                  </button>
                );
              })}
            </div>
          </div>
          <button onClick={onBack} className="text-left text-sm font-bold text-[#3D7A55] sm:text-right">+ Add another language</button>
        </section>
        <section className="grid overflow-hidden rounded-[28px] border border-[#DDE0D9] bg-white shadow-[0_2px_0_rgba(32,37,31,.04)] lg:grid-cols-[61.8fr_38.2fr]">
          <div className="p-7 sm:p-10">
            <p className="eyebrow text-[#4B7A5C]">Your personalized {language} path</p>
            <h1 className="mt-4 text-4xl font-semibold tracking-[-0.05em] sm:text-5xl">Welcome to your CodeXP.</h1>
            <p className="mt-4 max-w-2xl leading-relaxed text-[#656A63]">Learn {language} through focused lessons, hands-on coding, and projects that turn concepts into real skills.</p>
          </div>
          <div className="flex items-center gap-3 border-t border-[#E4E5E0] bg-[#F0F5F1] p-7 lg:justify-center lg:border-l lg:border-t-0">
            <button onClick={onStart} className="primary-button">Start lesson 1 <span>→</span></button>
          </div>
        </section>

        <section className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            ["Course progress", "0%", "0 of 14 lessons"],
            ["Learning streak", "0 days", "Start your streak today"],
            ["Tasks completed", "0 / 14", "Practice tasks passed"],
            ["Achievements", "0 / 5", "Milestones unlocked"],
          ].map(([label, value, detail], index) => (
            <article key={label} className="rounded-[22px] border border-[#DDE0D9] bg-white p-5 sm:p-6">
              <div className="mb-5 flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-[0.1em] text-[#666C64]">{label}</p><span className={`grid h-7 w-7 place-items-center rounded-full text-xs font-bold ${["bg-[#DDEDE3] text-[#39704E]", "bg-[#FFF0C7] text-[#9B6C09]", "bg-[#E1E8FA] text-[#4B68A5]", "bg-[#F1DFF3] text-[#875193]"][index]}`}>{index + 1}</span></div>
              <p className="text-3xl font-bold tracking-[-0.04em]">{value}</p>
              <p className="mt-2 text-xs text-[#767B74]">{detail}</p>
            </article>
          ))}
        </section>

        <section className="mt-10">
          <div className="mb-5 flex items-end justify-between">
            <div><h2 className="text-2xl font-bold tracking-[-0.035em]">Your learning tracks</h2><p className="mt-1 text-sm text-[#6B7069]">A three-tier path from first principles to independent projects.</p></div>
            <span className="hidden text-sm font-bold text-[#3D7A55] sm:block">14 lessons total</span>
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            {tracks.map((track, index) => (
              <article key={track.level} className="flex min-h-[290px] flex-col rounded-[24px] border border-[#DDE0D9] bg-white p-6">
                <div className="flex items-center justify-between"><p className={`text-xs font-bold tracking-[0.12em] ${track.accent}`}>{track.level}</p><p className="text-xs font-semibold text-[#71766F]">{track.count}</p></div>
                <h3 className="mt-6 text-xl font-bold tracking-[-0.025em]">{track.title}</h3>
                <p className="mt-3 text-sm leading-6 text-[#666B64]">{track.copy}</p>
                <div className="mt-auto pt-6">
                  <div className="mb-5 h-1.5 overflow-hidden rounded-full bg-[#ECEEEA]"><div className="h-full w-0 bg-[#5C966E]" /></div>
                  <button onClick={index === 0 ? onStart : undefined} className={`w-full rounded-xl px-4 py-3 text-sm font-bold ${index === 0 ? "bg-[#20251F] text-white" : "bg-[#F0F1EE] text-[#555A54]"}`}>{track.action} <span className="ml-2">→</span></button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="mt-6 grid items-center gap-6 rounded-[24px] border border-[#DDE0D9] bg-white p-6 sm:p-8 lg:grid-cols-[61.8fr_38.2fr]">
          <div>
            <p className="eyebrow text-[#4B7A5C]">Recommended next lesson</p>
            <h2 className="mt-3 text-xl font-bold tracking-[-0.025em]">01. {lessonCopy[language].title}</h2>
            <p className="mt-2 text-sm leading-6 text-[#666B64]">{lessonCopy[language].intro}</p>
          </div>
          <button onClick={onStart} className="primary-button lg:ml-auto">Start lesson <span>→</span></button>
        </section>
      </div>
    </main>
  );
}

function Learning({ language, onExit }: { language: Language; onExit: () => void }) {
  const lesson = lessonCopy[language];
  const [code, setCode] = useState(lesson.code);
  const [output, setOutput] = useState("Ready when you are.");
  const run = () => {
    const match = code.match(/["'](.+?)["']/);
    setOutput(match?.[1] || "Nice work — your code ran successfully.");
  };

  return (
    <main className="flex min-h-screen flex-col bg-[#F7F5EF]">
      <header className="flex h-20 items-center justify-between border-b border-[#DEDDD6] px-5 sm:px-8">
        <Logo />
        <div className="hidden items-center gap-3 sm:flex"><span className="text-sm font-semibold">{language} foundations</span><span className="rounded-full bg-[#E6E9E3] px-3 py-1.5 text-xs font-bold">Lesson 1 of 12</span></div>
        <button onClick={onExit} className="secondary-button !px-4 !py-2 text-sm">Exit lesson</button>
      </header>
      <div className="h-1.5 bg-[#E4E2DA]"><div className="h-full w-[8.3%] bg-[#68A983]" /></div>
      <div className="grid flex-1 lg:grid-cols-[61.8fr_38.2fr]">
        <section className="flex min-h-[560px] flex-col bg-[#20251F] p-5 text-white sm:p-8">
          <div className="mb-5 flex items-center justify-between">
            <div><p className="eyebrow text-[#99A097]">Practice space</p><h1 className="mt-2 text-xl font-semibold">Try it yourself</h1></div>
            <button onClick={() => setCode(lesson.code)} className="text-xs font-semibold text-[#B7BDB4] hover:text-white">Reset code</button>
          </div>
          <div className="flex min-h-[300px] flex-1 overflow-hidden rounded-t-2xl border border-[#3A4039] bg-[#181C18]">
            <div className="w-12 border-r border-[#30352F] pt-5 text-center font-mono text-sm leading-7 text-[#697068]">1<br />2<br />3</div>
            <textarea value={code} onChange={(event) => setCode(event.target.value)} spellCheck={false} aria-label="Code editor" className="min-h-full flex-1 resize-none bg-transparent p-5 font-mono text-[15px] leading-7 text-[#F1D475] outline-none" />
          </div>
          <div className="rounded-b-2xl border border-t-0 border-[#3A4039] bg-[#111411]">
            <div className="flex items-center justify-between border-b border-[#30352F] px-4 py-3"><span className="text-xs font-bold uppercase tracking-[0.12em] text-[#8F968D]">Terminal</span><button onClick={run} className="rounded-lg bg-[#F4C84B] px-5 py-2 text-sm font-bold text-[#20251F]">Run code ▶</button></div>
            <div className="min-h-24 p-4 font-mono text-sm text-[#93CCA9]"><span className="mr-3 text-[#687067]">$</span>{output}</div>
          </div>
        </section>
        <aside className="overflow-y-auto border-l border-[#DEDDD6] bg-white p-7 sm:p-10 lg:p-12">
          <p className="eyebrow text-[#617067]">Lesson 01 · Output</p>
          <h2 className="mt-4 text-3xl font-semibold leading-tight tracking-[-0.045em]">{lesson.title}</h2>
          <p className="mt-6 leading-7 text-[#656A63]">{lesson.intro}</p>
          <div className="my-8 rounded-2xl bg-[#F1F0EB] p-5 font-mono text-sm text-[#385E48]">{lesson.code}</div>
          <h3 className="font-bold">How it works</h3>
          <ul className="mt-4 space-y-4 text-sm leading-6 text-[#656A63]">
            <li className="flex gap-3"><b className="step-dot">1</b><span>The function tells the computer to display something.</span></li>
            <li className="flex gap-3"><b className="step-dot">2</b><span>Quotation marks tell it that your message is text.</span></li>
          </ul>
          <div className="mt-9 rounded-2xl border border-[#D9E3DB] bg-[#F0F6F2] p-5">
            <p className="text-xs font-bold uppercase tracking-[0.12em] text-[#4A745B]">Your challenge</p>
            <p className="mt-2 text-sm leading-6 text-[#516057]">{lesson.hint}</p>
          </div>
          <button onClick={run} className="primary-button mt-8 w-full">Check my code <span>→</span></button>
        </aside>
      </div>
    </main>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [language, setLanguage] = useState<Language>("Python");
  const [selectedLanguages, setSelectedLanguages] = useState<Language[]>(["Python"]);
  if (screen === "login") return <Login onLogin={() => setScreen("onboarding")} />;
  if (screen === "onboarding") return <Onboarding onChoose={(choices) => { setSelectedLanguages(choices); setLanguage(choices[0]); setScreen("dashboard"); }} />;
  if (screen === "dashboard") return <Dashboard selectedLanguages={selectedLanguages} language={language} onLanguageChange={setLanguage} onStart={() => setScreen("learn")} onBack={() => setScreen("onboarding")} />;
  return <Learning language={language} onExit={() => setScreen("dashboard")} />;
}
